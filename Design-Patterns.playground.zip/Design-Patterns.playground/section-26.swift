let whiteboard = Whiteboard([Circle(), Square()])
whiteboard.draw("Red")