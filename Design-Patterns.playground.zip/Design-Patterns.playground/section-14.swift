let number = Number(double: 12.1)
let double = number.doubleValue()
let integer = number.integerValue()
